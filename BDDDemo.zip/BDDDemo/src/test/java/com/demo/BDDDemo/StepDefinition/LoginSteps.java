package com.demo.BDDDemo.StepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;

public class LoginSteps 
{
	WebDriver driver = null;
	@Given("the application")
	public void the_application() 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Kunal Shah\\Desktop\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.saucedemo.com/");
	}
	@When("i enter username")
	public void i_enter_username() 
	{
		driver.findElement(By.id("user-name")).sendKeys("standard_user");
	}
	@When("enter password")
	public void enter_password() 
	{
	    driver.findElement(By.id("password")).sendKeys("secret_sauce");
	}
	@When("click login button")
	public void click_login_button() 
	{
	    driver.findElement(By.id("login-button")).click();
	}
	@Then("login successful")
	public void login_successful() throws InterruptedException 
	{
		String title = driver.findElement(By.className("title")).getText();
		System.out.println(title);
		Assert.assertEquals("PRODUCTS", title);
		Thread.sleep(3000);
		driver.close();
	}
}