package com.demo.ws;

public class SayHello 
{
	private String sayHiToUser(String msg)
	{
		return "Hello To "+msg;
	}
}
