package com.demo.TDD;

public class Account 
{
	private int balance = 1500;

	public int deposit(int amount)
	{
		balance+=amount;
		return balance;
	}
	public int withdraw(int amount)
	{
		balance-=amount;
		return balance;
	}
}
