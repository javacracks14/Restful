package com.demo.TDD;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import junit.framework.Assert;

public class AppTest
{
	Calc c = null;
	@Before
	public void beforeTestCase()
	{
		c = new Calc();
		System.out.println("Before");
	}
	@Test
	public void testAddMethod()
	{
		Assert.assertEquals(50, c.add(20,30));
		System.out.println("Test Case Add");
	}
	@Test
	public void testSubMethod()
	{
		Assert.assertEquals(150, c.sub(200,50));
		System.out.println("Test Case Sub");
	}
	@Test
	public void testMulMethod()
	{
		Assert.assertEquals(50, c.mul(10,5));
		System.out.println("Test Case Mul");
	}
	@Test
	public void testDivMethod()
	{
		Assert.assertEquals(5, c.div(10,2));
		System.out.println("Test Cas Div");
	}
	@After
	public void afterTestCase()
	{
		c = null;
		System.out.println("After");
	}
}