package com.demo.TDD;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import junit.framework.Assert;

public class AccountTest 
{
	static Account acc=null;
	
	@BeforeClass
	public static void beforeTestCase()
	{
		acc = new Account();
		System.out.println("Before Class");
	}
	@Test
	public void testDepositMethod()
	{
		Assert.assertEquals(6500, acc.deposit(5000));
		System.out.println("Test Case Deposit");
	}
	@Test
	public void testWithdrawMethod()
	{
		Assert.assertEquals(5500, acc.withdraw(1000));
		System.out.println("Test Case Withdraw");
	}
	@AfterClass
	public static void afterTestCase()
	{
		acc=null;
		System.out.println("After Class");
	}
}
